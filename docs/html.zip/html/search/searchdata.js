var indexSectionsWithContent =
{
  0: "acefgpt",
  1: "t",
  2: "cgt",
  3: "cgt",
  4: "aept",
  5: "cgt",
  6: "cgt",
  7: "ft"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

