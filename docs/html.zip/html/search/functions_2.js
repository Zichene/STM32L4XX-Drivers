var searchData=
[
  ['tim_5fconfig_0',['TIM_config',['../tim_8h.html#a3ecfed8e3ce677c6f663d0dbec8219c4',1,'tim.h']]],
  ['tim_5fdisableperipheralclk_1',['TIM_disablePeripheralClk',['../tim_8h.html#a51fa45a8ad8271045073f95c61a75574',1,'tim.h']]],
  ['tim_5fenableperipheralclk_2',['TIM_enablePeripheralClk',['../tim_8h.html#a7e436dcd8d1f9df35649297fc25de9c9',1,'tim.h']]],
  ['tim_5fhasupdated_3',['TIM_hasUpdated',['../tim_8h.html#a9aefba36c49823c04220ebffd9426f81',1,'tim.h']]],
  ['tim_5freseteventflag_4',['TIM_resetEventFlag',['../tim_8h.html#a678b5813bb7929232e9346038a6c756d',1,'tim.h']]]
];
